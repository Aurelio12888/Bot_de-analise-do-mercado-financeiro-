function SignalDisplay({ signal, analyzing }) {
  try {
    if (analyzing) {
      return (
        <div className="card glow" data-name="signal-display" data-file="components/SignalDisplay.js">
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-[var(--primary-color)] mb-4"></div>
            <p className="text-xl font-semibold text-white">Processando Análise...</p>
            <p className="text-sm text-gray-400 mt-2">Verificando múltiplas estratégias</p>
          </div>
        </div>
      );
    }

    if (!signal) {
      return (
        <div className="card" data-name="signal-display" data-file="components/SignalDisplay.js">
          <div className="text-center py-12">
            <div className="icon-alert-circle text-6xl text-gray-600 mb-4"></div>
            <p className="text-gray-400">Aguardando análise do gráfico</p>
          </div>
        </div>
      );
    }

    const getSignalColor = () => {
      if (signal.direction === 'COMPRAR') return 'text-green-500';
      if (signal.direction === 'VENDER') return 'text-red-500';
      return 'text-yellow-500';
    };

    const getSignalIcon = () => {
      if (signal.direction === 'COMPRAR') return 'trending-up';
      if (signal.direction === 'VENDER') return 'trending-down';
      return 'minus';
    };

    return (
      <div className={`card glow ${signal.confidence > 80 ? 'border-2 border-[var(--primary-color)]' : ''}`}>
        <div className="text-center mb-6">
          <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full mb-4 ${
            signal.direction === 'COMPRAR' ? 'bg-green-900' : 
            signal.direction === 'VENDER' ? 'bg-red-900' : 'bg-yellow-900'
          }`}>
            <div className={`icon-${getSignalIcon()} text-4xl ${getSignalColor()}`}></div>
          </div>
          <h3 className="text-3xl font-bold mb-2">
            <span className={getSignalColor()}>
              🔥 {signal.direction}
            </span>
          </h3>
          <div className="text-5xl font-bold mb-4">
            <span className={getSignalColor()}>{signal.confidence}%</span>
          </div>
          <p className="text-gray-400">Precisão da Análise</p>
        </div>
        <div className="border-t border-gray-800 pt-4">
          <p className="text-sm text-gray-400 mb-2">📊 Análise Completa:</p>
          <p className="text-white">{signal.description}</p>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SignalDisplay component error:', error);
    return null;
  }
}