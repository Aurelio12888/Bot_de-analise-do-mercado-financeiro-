function AnalysisPanel() {
  try {
    const systemStats = [
      { label: 'Padrões Detectados', value: '25+', icon: 'scan' },
      { label: 'Estratégias Ativas', value: '15', icon: 'layers' },
      { label: 'Precisão Média', value: '89%', icon: 'target' }
    ];

    return (
      <div className="card" data-name="analysis-panel" data-file="components/AnalysisPanel.js">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center">
          <div className="icon-cpu text-xl text-[var(--accent-color)] mr-2"></div>
          Sistema de Análise
        </h3>
        <div className="space-y-4">
          {systemStats.map((stat, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-700 rounded-lg flex items-center justify-center">
                  <div className={`icon-${stat.icon} text-lg text-[var(--accent-color)]`}></div>
                </div>
                <span className="text-sm text-gray-300">{stat.label}</span>
              </div>
              <span className="text-lg font-bold text-white">{stat.value}</span>
            </div>
          ))}
        </div>
        <div className="mt-6 p-4 bg-gray-800 rounded-lg">
          <p className="text-xs text-gray-400 leading-relaxed">
            ⚠️ Este sistema NÃO executa operações automáticas. Apenas analisa e fornece sinais baseados em múltiplas estratégias avançadas.
          </p>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AnalysisPanel component error:', error);
    return null;
  }
}