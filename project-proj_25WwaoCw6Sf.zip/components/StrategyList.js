function StrategyList({ strategies }) {
  try {
    return (
      <div className="card mb-6" data-name="strategy-list" data-file="components/StrategyList.js">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center">
          <div className="icon-shield-check text-xl text-[var(--accent-color)] mr-2"></div>
          Estratégias Ativas
        </h3>
        {strategies.length === 0 ? (
          <p className="text-gray-500 text-sm">Aguardando análise...</p>
        ) : (
          <div className="space-y-2">
            {strategies.map((strategy, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    strategy.active ? 'bg-green-500' : 'bg-gray-600'
                  }`}></div>
                  <span className="text-sm text-white">{strategy.name}</span>
                </div>
                <span className="strategy-badge bg-[var(--primary-color)] bg-opacity-20 text-[var(--primary-color)]">
                  {strategy.score}%
                </span>
              </div>
            ))}
          </div>
        )}
        <div className="mt-4 pt-4 border-t border-gray-800">
          <p className="text-xs text-gray-500">
            ⚡ Confirmação requer 3+ estratégias simultâneas
          </p>
        </div>
      </div>
    );
  } catch (error) {
    console.error('StrategyList component error:', error);
    return null;
  }
}