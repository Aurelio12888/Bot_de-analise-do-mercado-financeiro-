function CaptureArea({ onAnalyze, analyzing }) {
  try {
    const [uploadedImage, setUploadedImage] = React.useState(null);
    const fileInputRef = React.useRef(null);

    const handleFileSelect = (e) => {
      const file = e.target.files[0];
      if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setUploadedImage(event.target.result);
        };
        reader.readAsDataURL(file);
      }
    };

    const handleAnalyze = () => {
      if (!uploadedImage) return;
      
      const mockData = {
        image: uploadedImage,
        candles: generateMockCandles(),
        timestamp: new Date().toISOString()
      };
      onAnalyze(mockData);
    };

    const generateMockCandles = () => {
      return Array.from({ length: 20 }, (_, i) => ({
        index: i,
        type: Math.random() > 0.5 ? 'bull' : 'bear',
        strength: Math.random() * 100
      }));
    };

    const handleDrop = (e) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setUploadedImage(event.target.result);
        };
        reader.readAsDataURL(file);
      }
    };

    const handleDragOver = (e) => {
      e.preventDefault();
    };

    return (
      <div className="card mb-6" data-name="capture-area" data-file="components/CaptureArea.js">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center">
            <div className="icon-camera text-xl text-[var(--primary-color)] mr-2"></div>
            Área de Captura
          </h2>
          {uploadedImage && (
            <button
              onClick={handleAnalyze}
              disabled={analyzing}
              className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {analyzing ? 'Analisando...' : '🔥 Analisar Gráfico'}
            </button>
          )}
        </div>
        <div 
          onClick={() => !uploadedImage && fileInputRef.current?.click()}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-all cursor-pointer ${
            uploadedImage ? 'border-green-500 bg-green-950 bg-opacity-20' : 'border-gray-700 hover:border-gray-600'
          }`}
        >
          {uploadedImage ? (
            <div className="relative">
              <img src={uploadedImage} alt="Gráfico" className="max-h-64 mx-auto rounded-lg" />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setUploadedImage(null);
                }}
                className="absolute top-2 right-2 bg-red-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-red-700"
              >
                Remover
              </button>
            </div>
          ) : (
            <>
              <div className="icon-upload text-6xl text-gray-600 mb-4"></div>
              <p className="text-gray-400 mb-2">Clique para fazer upload ou arraste o gráfico aqui</p>
              <p className="text-sm text-gray-600">Formatos: JPG, PNG, GIF</p>
            </>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>
      </div>
    );
  } catch (error) {
    console.error('CaptureArea component error:', error);
    return null;
  }
}
