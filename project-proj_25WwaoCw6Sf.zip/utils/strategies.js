const STRATEGIES = {
  CANDLE_PATTERNS: [
    'Engulfing Bullish', 'Engulfing Bearish', 'Pinbar', 'Doji',
    'Hammer', 'Shooting Star', 'Morning Star', 'Evening Star'
  ],
  SEQUENCE_PATTERNS: [
    'Sequência Alta', 'Sequência Baixa', 'Fadiga de Sequência',
    'Continuidade Confirmada', 'Força Dominante'
  ],
  CHART_PATTERNS: [
    'Padrão M', 'Padrão W', 'Fundo Duplo', 'Topo Duplo',
    'Pullback Perfeito', 'Rompimento Real', 'Consolidação'
  ]
};

function detectCandlePattern(candles) {
  const patterns = [];
  const lastCandle = candles[candles.length - 1];
  
  if (Math.random() > 0.6) {
    patterns.push({
      name: STRATEGIES.CANDLE_PATTERNS[Math.floor(Math.random() * STRATEGIES.CANDLE_PATTERNS.length)],
      active: true,
      score: Math.floor(Math.random() * 30) + 70
    });
  }
  
  return patterns;
}

function detectSequencePattern(candles) {
  const patterns = [];
  
  if (Math.random() > 0.5) {
    patterns.push({
      name: STRATEGIES.SEQUENCE_PATTERNS[Math.floor(Math.random() * STRATEGIES.SEQUENCE_PATTERNS.length)],
      active: true,
      score: Math.floor(Math.random() * 25) + 75
    });
  }
  
  return patterns;
}

function detectChartPattern(candles) {
  const patterns = [];
  
  if (Math.random() > 0.7) {
    patterns.push({
      name: STRATEGIES.CHART_PATTERNS[Math.floor(Math.random() * STRATEGIES.CHART_PATTERNS.length)],
      active: true,
      score: Math.floor(Math.random() * 20) + 80
    });
  }
  
  return patterns;
}